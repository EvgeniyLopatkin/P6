#include <8051.h>

void tput(unsigned char c1)
{
SBUF=c1;
while(!TI); 
TI=0;
}
void main()
{
char z;
int i;

unsigned char src[]={'a','b','c','c','c','c','c','c','c','c','c','c','c','c','c','c','c','c','c'};
TH1=0xFF;
PCON=0x80;
for(i=0; i<20; i++)
{
ACC=src[i];
SCON = 0xD9;

tput (src[i]);
}
while(0){}
}